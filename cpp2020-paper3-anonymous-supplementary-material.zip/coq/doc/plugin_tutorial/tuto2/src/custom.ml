(*
 * This file defines a custom type for the PassCustom command.
 *)

type custom_type = Foo | Bar
