- Record fields can be annotated to prevent them from being used as canonical projections;
  see :ref:`canonicalstructures` for details
  (`#10076 <https://github.com/coq/coq/pull/10076>`_,
  by Vincent Laporte).
