- Using ``SProp`` is now allowed by default, without needing to pass
  ``-allow-sprop`` or use :flag:`Allow StrictProp` (`#10811
  <https://github.com/coq/coq/pull/10811>`_, by Gaëtan Gilbert).
