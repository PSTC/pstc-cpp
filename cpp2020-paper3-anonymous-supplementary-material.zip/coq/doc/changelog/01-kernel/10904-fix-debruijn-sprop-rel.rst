- Fix proof of False when using |SProp| (incorrect De Bruijn handling
  when inferring the relevance mark of a function) (`#10904
  <https://github.com/coq/coq/pull/10904>`_, by Pierre-Marie Pédrot).
