- Removes deprecated modules `Coq.ZArith.Zlogarithm`
  and `Coq.ZArith.Zsqrt_compat`
  (#9881 <https://github.com/coq/coq/pull/9811>
  by Vincent Laporte).
