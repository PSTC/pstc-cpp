- New lemmas on :g:`combine`, :g:`filter`, :g:`nodup`, :g:`nth`, and
  :g:`nth_error` functions on lists. The lemma :g:`filter_app` was moved to the
  :g:`List` module.

  See `#10651 <https://github.com/coq/coq/pull/10651>`_, and
  `#10731 <https://github.com/coq/coq/pull/10731>`_, by Oliver Nash.
