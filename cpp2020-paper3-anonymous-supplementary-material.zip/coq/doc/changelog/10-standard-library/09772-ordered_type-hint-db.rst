-  Moved the `auto` hints of the `OrderedType` module into a new `ordered_type`
   database
   (`#9772 <https://github.com/coq/coq/pull/9772>`_,
   by Vincent Laporte).
