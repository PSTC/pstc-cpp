- Remove ``Show Script`` command (deprecated since 8.10)
  (`#10277 <https://github.com/coq/coq/pull/10277>`_, by Gaëtan Gilbert).
