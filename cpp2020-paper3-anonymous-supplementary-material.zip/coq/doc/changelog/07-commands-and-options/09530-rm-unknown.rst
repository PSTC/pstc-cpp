- Deprecated flag `Refine Instance Mode` has been removed.
  (`#9530 <https://github.com/coq/coq/pull/9530>`_, fixes
  `#3632 <https://github.com/coq/coq/issues/3632>`_, `#3890
  <https://github.com/coq/coq/issues/3890>`_ and `#4638
  <https://github.com/coq/coq/issues/4638>`_
  by Maxime Dénès, review by Gaëtan Gilbert).
