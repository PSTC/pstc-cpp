- Remove undocumented :n:`Instance : !@type` syntax
  (`#10185 <https://github.com/coq/coq/pull/10185>`_, by Gaëtan Gilbert).
