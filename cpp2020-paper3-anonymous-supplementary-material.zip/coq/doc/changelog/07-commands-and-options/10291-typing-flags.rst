- Adding unsafe commands to enable/disable guard checking, positivity checking
  and universes checking (providing a local `-type-in-type`).
  See :ref:`controlling-typing-flags`.
  (`#10291 <https://github.com/coq/coq/pull/10291>`_ by Simon Boulier).
