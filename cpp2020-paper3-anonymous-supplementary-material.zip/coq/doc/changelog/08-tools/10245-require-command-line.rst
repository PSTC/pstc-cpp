- Add command line options `-require-import`, `-require-export`,
  `-require-import-from` and `-require-export-from`, as well as their
  shorthand, `-ri`, `-re`, `-refrom` and -`rifrom`. Deprecate
  confusing command line option `-require`
  (`#10245 <https://github.com/coq/coq/pull/10245>`_
  by Hugo Herbelin, review by Emilio Gallego).
