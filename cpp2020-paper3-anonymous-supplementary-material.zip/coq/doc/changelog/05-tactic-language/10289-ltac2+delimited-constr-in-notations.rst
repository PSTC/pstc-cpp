- Ltac2 tactic notations with “constr” arguments can specify the
  interpretation scope for these arguments;
  see :ref:`ltac2_notations` for details
  (`#10289 <https://github.com/coq/coq/pull/10289>`_,
  by Vincent Laporte).
