- White spaces are forbidden in the “&ident” syntax for ltac2 references
  that are described in :ref:`ltac2_built-in-quotations`
  (`#10324 <https://github.com/coq/coq/pull/10324>`_,
  fixes `#10088 <https://github.com/coq/coq/issues/10088>`_,
  authored by Pierre-Marie Pédrot).
