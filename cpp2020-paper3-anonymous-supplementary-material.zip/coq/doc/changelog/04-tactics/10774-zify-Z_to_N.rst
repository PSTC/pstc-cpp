- The :tacn:`zify` tactic is now aware of `Z.to_N`.
  (`#10774 <https://github.com/coq/coq/pull/10774>`_ fixes
  `#9162 <https://github.com/coq/coq/issues/9162>`_, by Kazuhiko Sakaguchi).
