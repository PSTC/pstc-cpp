- Documented syntax :n:`injection @term as [= {+ @intropattern} ]` as
  an alternative to :n:`injection @term as {+ @simple_intropattern}` using
  the standard :n:`@injection_intropattern` syntax (`#9288
  <https://github.com/coq/coq/pull/9288>`_, by Hugo Herbelin).
