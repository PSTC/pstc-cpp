- The goal selector tactical ``only`` now checks that the goal range
  it is given is valid instead of ignoring goals out of the focus
  range (`#10318 <https://github.com/coq/coq/pull/10318>`_, by Gaëtan
  Gilbert).
