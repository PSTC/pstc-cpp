if [ "$CI_PULL_REQUEST" = "10434" ] || [ "$CI_BRANCH" = "proof+hook_record" ]; then

    equations_CI_REF=proof+hook_record
    equations_CI_GITURL=https://github.com/ejgallego/Coq-Equations

    mtac2_CI_REF=proof+hook_record
    mtac2_CI_GITURL=https://github.com/ejgallego/Mtac2

    paramcoq_CI_REF=proof+hook_record
    paramcoq_CI_GITURL=https://github.com/ejgallego/paramcoq

fi
