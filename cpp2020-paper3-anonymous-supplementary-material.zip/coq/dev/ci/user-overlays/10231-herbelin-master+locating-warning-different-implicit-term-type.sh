if [ "$CI_PULL_REQUEST" = "10231" ] || [ "$CI_BRANCH" = "master+locating-warning-different-implicit-term-type" ]; then

    equations_CI_REF=master+fix-manual-implicit-pr10231
    equations_CI_GITURL=https://github.com/herbelin/Coq-Equations

    mtac2_CI_REF=master+fix-manual-implicit-pr10231
    mtac2_CI_GITURL=https://github.com/herbelin/Mtac2

fi
