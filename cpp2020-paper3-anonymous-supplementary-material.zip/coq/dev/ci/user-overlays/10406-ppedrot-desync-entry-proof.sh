if [ "$CI_PULL_REQUEST" = "10406" ] || [ "$CI_BRANCH" = "desync-entry-proof" ]; then

    equations_CI_REF=desync-entry-proof
    equations_CI_GITURL=https://github.com/ppedrot/Coq-Equations

    quickchick_CI_REF=desync-entry-proof
    quickchick_CI_GITURL=https://github.com/ppedrot/QuickChick

fi
