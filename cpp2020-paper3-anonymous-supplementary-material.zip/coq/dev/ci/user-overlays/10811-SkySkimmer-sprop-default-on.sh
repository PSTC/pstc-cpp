if [ "$CI_PULL_REQUEST" = "10811" ] || [ "$CI_BRANCH" = "sprop-default-on" ]; then

    elpi_CI_REF=sprop-default-on
    elpi_CI_GITURL=https://github.com/SkySkimmer/coq-elpi

    coq_dpdgraph_CI_REF=sprop-default-on
    coq_dpdgraph_CI_GITURL=https://github.com/SkySkimmer/coq-dpdgraph

fi
