if [ "$CI_PULL_REQUEST" = "10185" ] || [ "$CI_BRANCH" = "instance-no-bang" ]; then

    quickchick_CI_REF=instance-no-bang
    quickchick_CI_GITURL=https://github.com/SkySkimmer/QuickChick

fi
