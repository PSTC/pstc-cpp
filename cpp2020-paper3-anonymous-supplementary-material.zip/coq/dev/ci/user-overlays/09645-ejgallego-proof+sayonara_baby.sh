if [ "$CI_PULL_REQUEST" = "9645" ] || [ "$CI_BRANCH" = "proof+sayonara_baby" ]; then

    equations_CI_REF=proof+sayonara_baby
    equations_CI_GITURL=https://github.com/ejgallego/Coq-Equations

    mtac2_CI_REF=proof+sayonara_baby
    mtac2_CI_GITURL=https://github.com/ejgallego/Mtac2

    paramcoq_CI_REF=proof+sayonara_baby
    paramcoq_CI_GITURL=https://github.com/ejgallego/paramcoq

fi
