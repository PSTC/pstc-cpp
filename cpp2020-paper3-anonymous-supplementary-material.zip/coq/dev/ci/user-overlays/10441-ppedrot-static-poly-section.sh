if [ "$CI_PULL_REQUEST" = "10441" ] || [ "$CI_BRANCH" = "static-poly-section" ]; then

    ext_lib_CI_REF=static-poly-section
    ext_lib_CI_GITURL=https://github.com/ppedrot/coq-ext-lib

fi
