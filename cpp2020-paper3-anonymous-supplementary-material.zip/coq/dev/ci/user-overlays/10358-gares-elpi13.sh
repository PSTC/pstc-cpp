if [ "$CI_PULL_REQUEST" = "10358" ] || [ "$CI_BRANCH" = "elpi-13-coq" ]; then

    elpi_CI_REF="elpi-13-coq"
    elpi_CI_GITURL=https://github.com/LPCIC/coq-elpi

fi
