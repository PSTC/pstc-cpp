if [ "$CI_PULL_REQUEST" = "10476" ] || [ "$CI_BRANCH" = "rm-library-optim" ]; then

    sf_lf_CI_TARURL=https://www.maximedenes.fr/download/lf.tgz
    sf_plf_CI_TARURL=https://www.maximedenes.fr/download/plf.tgz
    sf_vfa_CI_TARURL=https://www.maximedenes.fr/download/vfa.tgz

    vst_CI_REF=fix-export
    vst_CI_GITURL=https://github.com/maximedenes/VST

fi
