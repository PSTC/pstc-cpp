if [ "$CI_PULL_REQUEST" = "10319" ] || [ "$CI_BRANCH" = "vernac-when-sideff" ]; then

    mtac2_CI_REF=vernac-when-sideff
    mtac2_CI_GITURL=https://github.com/SkySkimmer/Mtac2

    equations_CI_REF=vernac-when-sideff
    equations_CI_GITURL=https://github.com/SkySkimmer/Coq-Equations

fi
