if [ "$CI_PULL_REQUEST" = "10642" ] || [ "$CI_BRANCH" = "feedback-added-axiom" ]; then

    elpi_CI_REF=feedback-added-axiom
    elpi_CI_GITURL=https://github.com/SkySkimmer/coq-elpi

fi
