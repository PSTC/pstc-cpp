if [ "$CI_PULL_REQUEST" = "10665" ] || [ "$CI_BRANCH" = "api+varkind" ]; then

    elpi_CI_REF=api+varkind
    elpi_CI_GITURL=https://github.com/ejgallego/coq-elpi

    quickchick_CI_REF=api+varkind
    quickchick_CI_GITURL=https://github.com/ejgallego/QuickChick

fi
