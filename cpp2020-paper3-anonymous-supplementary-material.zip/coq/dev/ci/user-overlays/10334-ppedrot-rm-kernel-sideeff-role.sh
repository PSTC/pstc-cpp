if [ "$CI_PULL_REQUEST" = "10334" ] || [ "$CI_BRANCH" = "rm-kernel-sideeff-role" ]; then

    equations_CI_REF=rm-kernel-sideeff-role
    equations_CI_GITURL=https://github.com/ppedrot/Coq-Equations

fi
