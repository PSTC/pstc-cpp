if [ "$CI_PULL_REQUEST" = "10674" ] || [ "$CI_BRANCH" = "proofs+declare_unif" ]; then

    equations_CI_REF=proofs+declare_unif
    equations_CI_GITURL=https://github.com/ejgallego/Coq-Equations

fi
