if [ "$CI_PULL_REQUEST" = "10738" ] || [ "$CI_BRANCH" = "elpi1.7" ]; then

    elpi_CI_REF="coq-master+elpi1.7"
    elpi_CI_GITURL=https://github.com/LPCIC/coq-elpi

fi
