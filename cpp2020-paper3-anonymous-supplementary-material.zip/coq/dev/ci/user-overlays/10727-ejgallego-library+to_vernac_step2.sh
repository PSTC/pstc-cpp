if [ "$CI_PULL_REQUEST" = "10727" ] || [ "$CI_BRANCH" = "library+to_vernac_step2" ]; then

    elpi_CI_REF=library+to_vernac_step2
    elpi_CI_GITURL=https://github.com/ejgallego/coq-elpi

fi
