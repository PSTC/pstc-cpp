if [ "$CI_PULL_REQUEST" = "9566" ] || [ "$CI_BRANCH" = "proof_global+move_termination_routine_out" ]; then

    aac_tactics_CI_REF=proof_global+move_termination_routine_out
    aac_tactics_CI_GITURL=https://github.com/ejgallego/aac-tactics

    equations_CI_REF=proof_global+move_termination_routine_out
    equations_CI_GITURL=https://github.com/ejgallego/Coq-Equations

    paramcoq_CI_REF=proof_global+move_termination_routine_out
    paramcoq_CI_GITURL=https://github.com/ejgallego/paramcoq

fi
